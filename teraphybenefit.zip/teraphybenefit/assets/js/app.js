document.addEventListener("DOMContentLoaded",()=>{
 document.querySelectorAll(".phone-input").forEach(input=>{
  input.addEventListener("input",()=>{
   let d=input.value.replace(/\D/g,"").slice(0,10);
   input.value=(d.match(/.{1,2}/g)||[]).join(" ");
  });
 });
 document.querySelectorAll('input[type="date"]').forEach(i=>i.setAttribute("lang","es-MX"));
});