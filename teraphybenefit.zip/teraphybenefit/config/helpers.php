<?php
if(session_status()===PHP_SESSION_NONE) session_start();
function e($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function redirect($u){ header("Location: $u"); exit; }
function role(){ return $_SESSION['usuario']['rol'] ?? ''; }
function is_admin(){ return role()==='admin'; }
function is_doctor(){ return role()==='doctor'; }
function is_patient(){ return role()==='paciente'; }
function require_login(){ if(!isset($_SESSION['usuario'])) redirect('index.php'); }
function require_admin(){ require_login(); if(!is_admin()) redirect('dashboard.php'); }
function require_staff(){ require_login(); if(is_patient()) redirect('patient_portal.php'); }
function name(){ return $_SESSION['usuario']['nombre_completo'] ?? 'Usuario'; }
function first_name(){ $p=explode(' ',name()); return $p[1]??$p[0]??'Usuario'; }
function pass_rules(){ return 'Mínimo 8 caracteres, una mayúscula, una minúscula, un número y un carácter especial.'; }
function pass_ok($p){ return strlen($p)>=8 && preg_match('/[A-Z]/',$p) && preg_match('/[a-z]/',$p) && preg_match('/[0-9]/',$p) && preg_match('/[^A-Za-z0-9]/',$p); }
function doctor_id($db){ if(!is_doctor()) return null; $s=$db->prepare('SELECT id_doctor FROM doctores WHERE id_usuario=? LIMIT 1'); $s->execute([$_SESSION['usuario']['id_usuario']]); $id=$s->fetchColumn(); return $id?intval($id):null; }
function logo($blue=false){ $c=$blue?'logo logo--blue':'logo'; return "<div class='$c'><div class='logo__icon'>❤</div><div><strong>TERAPHY</strong><span>BENEFIT</span></div></div>"; }
function header_page($title,$active){ ?>
<!DOCTYPE html><html lang="es"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>TeraphyBenefit | <?=e($title)?></title><link rel="stylesheet" href="assets/css/styles.css"></head><body>
<aside class="sidebar"><div class="sidebar-logo"><?=logo(false)?></div><nav class="nav-menu">
<?php if(is_admin()): ?>
<a class="nav-item <?=$active==='admin'?'is-active':''?>" href="admin_dashboard.php">⌂ <span>Panel admin</span></a>
<a class="nav-item <?=$active==='doctores'?'is-active':''?>" href="doctors.php">🩺 <span>Doctores</span></a>
<a class="nav-item <?= $active==='productos'?'is-active':'' ?>" href="products.php">🛒 <span>Productos</span></a>
<?php elseif(is_doctor()): ?>
<a class="nav-item <?=$active==='inicio'?'is-active':''?>" href="dashboard.php">⌂ <span>Inicio</span></a>
<a class="nav-item <?=$active==='pacientes'?'is-active':''?>" href="patients.php">👥 <span>Pacientes</span></a>
<a class="nav-item <?=$active==='agenda'?'is-active':''?>" href="appointments.php">📅 <span>Agenda</span></a>
<a class="nav-item <?=$active==='notas'?'is-active':''?>" href="sessions.php">📝 <span>Notas SOAP</span></a>
<a class="nav-item <?=$active==='reportes'?'is-active':''?>" href="reports.php">📈 <span>Reportes</span></a>
<?php else: ?>
<a class="nav-item <?=$active==='portal'?'is-active':''?>" href="patient_portal.php">📈 <span>Mi seguimiento</span></a>
<a class="nav-item <?=$active==='tienda'?'is-active':''?>" href="store.php">🛒 <span>Tienda</span></a>
<a class="nav-item <?=$active==='carrito'?'is-active':''?>" href="cart.php">🧺 <span>Carrito</span></a>
<a class="nav-item <?=$active==='pedidos'?'is-active':''?>" href="orders.php">📦 <span>Mis pedidos</span></a>
<?php endif; ?>
<a class="nav-item nav-item--logout" href="logout.php">↩ <span>Cerrar sesión</span></a></nav></aside>
<main class="main-content"><header class="topbar"><form class="patient-search" action="patients.php" method="GET"><input type="search" name="q" placeholder="Búsqueda rápida por paciente..." <?=is_patient()||is_admin()?'disabled':''?>></form><div class="doctor-profile"><div class="avatar"><?=e(strtoupper(substr(name(),0,2)))?></div><div><strong><?=e(name())?></strong><span><?=e(role())?></span></div></div></header>
<?php } function footer_page(){ echo '</main><script src="assets/js/app.js"></script></body></html>'; } ?>