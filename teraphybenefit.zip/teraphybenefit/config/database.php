<?php
class Database {
    private string $host = "localhost";
    private string $db_name = "teraphybenefit";
    private string $username = "root";
    private string $password = "";
    private ?PDO $conn = null;
    public function connect(): PDO {
        if ($this->conn === null) {
            $this->conn = new PDO("mysql:host={$this->host};dbname={$this->db_name};charset=utf8mb4",$this->username,$this->password);
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        }
        return $this->conn;
    }
}
?>