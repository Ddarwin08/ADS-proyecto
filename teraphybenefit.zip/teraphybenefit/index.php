<?php
require_once "config/helpers.php";
if(isset($_SESSION['usuario'])){ if(is_admin()) redirect('admin_dashboard.php'); if(is_doctor()) redirect('dashboard.php'); redirect('patient_portal.php'); }
$error=$_GET['error']??'';
?>
<!DOCTYPE html><html lang="es"><head><meta charset="UTF-8"><title>TeraphyBenefit | Acceso</title><link rel="stylesheet" href="assets/css/styles.css"></head><body class="login-screen">
<section class="login-card">
<div class="login-logo-custom"><?=logo(true)?></div>
<h2>Iniciar sesión</h2><p>Accede a tu cuenta</p>
<?php if($error): ?><div class="alert">Usuario o contraseña incorrectos.</div><?php endif; ?>
<form action="login.php" method="POST"><label>Usuario</label><input name="usuario" required placeholder="Ingresa tu usuario"><label>Contraseña</label><input type="password" name="contrasena" required placeholder="Ingresa tu contraseña"><button>Iniciar sesión</button></form>
</section></body></html>