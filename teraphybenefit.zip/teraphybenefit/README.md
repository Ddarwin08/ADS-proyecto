# TeraphyBenefit Final

Usuarios:
- Admin: admin / Admin123!
- Doctor: doctor1 / Doctor123!
- Paciente: javier / Javier123!

Incluye admin general, doctores, pacientes, tienda, carrito, pedidos, productos, notas SOAP, citas y reportes.

Instalación:
1. Copia `teraphybenefit_final` en `C:\xampp\htdocs\`.
2. Inicia Apache y MySQL.
3. Importa `database/teraphybenefit.sql` en phpMyAdmin.
4. Abre `http://localhost/teraphybenefit_final/`.
