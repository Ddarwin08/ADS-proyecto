<?php
session_start(); require_once "config/database.php";
$db=(new Database())->connect();
$s=$db->prepare("SELECT * FROM usuarios WHERE nombre_usuario=? AND contrasena=? LIMIT 1");
$s->execute([$_POST['usuario']??'', $_POST['contrasena']??'']);
$u=$s->fetch(PDO::FETCH_ASSOC);
if($u){ $_SESSION['usuario']=$u; if($u['rol']==='admin') header('Location: admin_dashboard.php'); elseif($u['rol']==='doctor') header('Location: dashboard.php'); else header('Location: patient_portal.php'); exit; }
header('Location: index.php?error=1'); exit;
?>