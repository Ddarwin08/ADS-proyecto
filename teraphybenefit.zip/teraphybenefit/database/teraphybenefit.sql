CREATE DATABASE IF NOT EXISTS teraphybenefit CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE teraphybenefit;
SET FOREIGN_KEY_CHECKS=0;
DROP TABLE IF EXISTS carrito; DROP TABLE IF EXISTS pedidos_detalle; DROP TABLE IF EXISTS pedidos; DROP TABLE IF EXISTS productos;
DROP TABLE IF EXISTS sesiones; DROP TABLE IF EXISTS citas; DROP TABLE IF EXISTS pacientes; DROP TABLE IF EXISTS doctores; DROP TABLE IF EXISTS usuarios;
SET FOREIGN_KEY_CHECKS=1;

CREATE TABLE usuarios(
 id_usuario INT AUTO_INCREMENT PRIMARY KEY,
 nombre_usuario VARCHAR(50) UNIQUE NOT NULL,
 contrasena VARCHAR(255) NOT NULL,
 nombre_completo VARCHAR(100) NOT NULL,
 rol ENUM('admin','doctor','paciente') NOT NULL,
 creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE doctores(
 id_doctor INT AUTO_INCREMENT PRIMARY KEY,
 id_usuario INT NOT NULL,
 especialidad VARCHAR(100) NOT NULL,
 correo VARCHAR(100),
 telefono VARCHAR(20),
 activo TINYINT DEFAULT 1,
 FOREIGN KEY(id_usuario) REFERENCES usuarios(id_usuario) ON DELETE CASCADE
);

CREATE TABLE pacientes(
 id_paciente INT AUTO_INCREMENT PRIMARY KEY,
 id_usuario INT NULL,
 id_doctor INT NULL,
 nombre VARCHAR(100) NOT NULL,
 edad INT NOT NULL,
 genero VARCHAR(30),
 lesion VARCHAR(150),
 contacto VARCHAR(20),
 fecha_inicio DATE NOT NULL,
 estado ENUM('activo','seguimiento','alta') DEFAULT 'activo',
 nota_inicial TEXT,
 creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(id_usuario) REFERENCES usuarios(id_usuario) ON DELETE SET NULL,
 FOREIGN KEY(id_doctor) REFERENCES doctores(id_doctor) ON DELETE SET NULL
);

CREATE TABLE citas(
 id_cita INT AUTO_INCREMENT PRIMARY KEY,
 id_paciente INT NOT NULL,
 id_doctor INT NULL,
 fecha DATE NOT NULL,
 hora TIME NOT NULL,
 motivo VARCHAR(180) DEFAULT 'Sesión de fisioterapia',
 estado ENUM('pendiente','realizada','cancelada') DEFAULT 'pendiente',
 notas TEXT,
 FOREIGN KEY(id_paciente) REFERENCES pacientes(id_paciente) ON DELETE CASCADE,
 FOREIGN KEY(id_doctor) REFERENCES doctores(id_doctor) ON DELETE SET NULL
);

CREATE TABLE sesiones(
 id_sesion INT AUTO_INCREMENT PRIMARY KEY,
 id_paciente INT NOT NULL,
 id_doctor INT NULL,
 fecha DATE NOT NULL,
 hora TIME NULL,
 tipo_terapia VARCHAR(100) NOT NULL,
 ejercicios TEXT,
 signos_vitales TEXT,
 observaciones TEXT,
 evolucion_actual TEXT,
 nivel_dolor SMALLINT NOT NULL,
 recomendaciones TEXT,
 FOREIGN KEY(id_paciente) REFERENCES pacientes(id_paciente) ON DELETE CASCADE,
 FOREIGN KEY(id_doctor) REFERENCES doctores(id_doctor) ON DELETE SET NULL,
 CHECK(nivel_dolor BETWEEN 1 AND 10)
);

CREATE TABLE productos(
 id_producto INT AUTO_INCREMENT PRIMARY KEY,
 nombre VARCHAR(100) NOT NULL,
 descripcion TEXT,
 precio DECIMAL(10,2) NOT NULL,
 stock INT NOT NULL DEFAULT 0,
 imagen_emoji VARCHAR(10) DEFAULT '🛒',
 imagen VARCHAR(120) DEFAULT 'producto-default.svg',
 activo TINYINT DEFAULT 1
);

CREATE TABLE carrito(
 id_carrito INT AUTO_INCREMENT PRIMARY KEY,
 id_usuario INT NOT NULL,
 id_producto INT NOT NULL,
 cantidad INT NOT NULL DEFAULT 1,
 FOREIGN KEY(id_usuario) REFERENCES usuarios(id_usuario) ON DELETE CASCADE,
 FOREIGN KEY(id_producto) REFERENCES productos(id_producto) ON DELETE CASCADE
);

CREATE TABLE pedidos(
 id_pedido INT AUTO_INCREMENT PRIMARY KEY,
 id_usuario INT NOT NULL,
 fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 total DECIMAL(10,2) NOT NULL,
 estado ENUM('completado','pendiente') DEFAULT 'completado',
 FOREIGN KEY(id_usuario) REFERENCES usuarios(id_usuario) ON DELETE CASCADE
);

CREATE TABLE pedidos_detalle(
 id_detalle INT AUTO_INCREMENT PRIMARY KEY,
 id_pedido INT NOT NULL,
 id_producto INT NOT NULL,
 cantidad INT NOT NULL,
 precio_unitario DECIMAL(10,2) NOT NULL,
 FOREIGN KEY(id_pedido) REFERENCES pedidos(id_pedido) ON DELETE CASCADE,
 FOREIGN KEY(id_producto) REFERENCES productos(id_producto) ON DELETE CASCADE
);

INSERT INTO usuarios(nombre_usuario,contrasena,nombre_completo,rol) VALUES
('admin','Admin123!','Administrador General','admin'),
('doctor1','Doctor123!','Dr. Carlos Borjas','doctor'),
('javier','Javier123!','Javier Mendoza','paciente'),
('ana','Ana12345!','Ana López','paciente');

INSERT INTO doctores(id_usuario,especialidad,correo,telefono) VALUES
(2,'Rehabilitación física','carlos@teraphybenefit.com','55 55 55 55 55');

INSERT INTO pacientes(id_usuario,id_doctor,nombre,edad,genero,lesion,contacto,fecha_inicio,estado,nota_inicial) VALUES
(3,1,'Javier Mendoza',34,'Masculino','Esguince de tobillo grado 2','55 51 23 45 67','2026-05-10','seguimiento','Paciente con dolor al caminar.'),
(4,1,'Ana López',28,'Femenino','Dolor lumbar mecánico','55 57 65 43 21','2026-05-14','activo','Dolor lumbar posterior a esfuerzo.'),
(NULL,1,'María Torres',41,'Femenino','Lesión de rodilla','55 59 87 65 43','2026-05-20','activo','Limitación funcional.');

INSERT INTO citas(id_paciente,id_doctor,fecha,hora,motivo,estado) VALUES
(1,1,CURDATE(),'10:00:00','Revisión de movilidad','pendiente'),
(2,1,CURDATE(),'12:00:00','Seguimiento lumbar','pendiente'),
(3,1,DATE_ADD(CURDATE(), INTERVAL 1 DAY),'16:00:00','Fortalecimiento','pendiente');

INSERT INTO sesiones(id_paciente,id_doctor,fecha,hora,tipo_terapia,ejercicios,signos_vitales,observaciones,evolucion_actual,nivel_dolor,recomendaciones) VALUES
(1,1,'2026-05-12','10:00:00','Movilidad','Rango articular y apoyo parcial.','TA 120/80, FC 76','Dolor moderado al caminar.','Inicia con dolor moderado.',7,'Ejercicios suaves en casa.'),
(1,1,'2026-05-19','10:00:00','Fortalecimiento','Propiocepción y carga progresiva.','TA 118/78, FC 74','Mejora parcial.','Disminución del dolor.',6,'Mantener fortalecimiento.'),
(2,1,'2026-05-16','12:00:00','Estiramiento','Estiramientos lumbares.','TA 116/75','Dolor al flexionar.','Disminución leve.',5,'Evitar cargas pesadas.');

INSERT INTO productos(nombre,descripcion,precio,stock,imagen_emoji,imagen) VALUES
('Ligas de resistencia','Set de ligas para ejercicios de movilidad y fortalecimiento.',150.00,25,'🏋️','ligas-resistencia.svg'),
('Mancuernas 2kg','Par de mancuernas para rehabilitación.',280.00,18,'💪','mancuernas-2kg.svg'),
('Pelota de ejercicio','Pelota para equilibrio, pilates y estabilidad.',320.00,15,'🔵','pelota-ejercicio.svg'),
('Rodillo de espuma','Rodillo para masaje muscular y liberación de tensión.',250.00,20,'⚫','rodillo-espuma.svg'),
('Banda elástica','Banda para estiramientos y terapia física.',120.00,30,'🟦','banda-elastica.svg');
